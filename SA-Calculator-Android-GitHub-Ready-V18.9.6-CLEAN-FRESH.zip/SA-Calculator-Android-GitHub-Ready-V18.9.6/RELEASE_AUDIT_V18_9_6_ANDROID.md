# SA Calculator Android V18.9.6 — Release / CI Audit

## Source-level verification completed

- Native C++17 engine compile with `-Wall -Wextra -Wpedantic`: PASS
- JNI bridge compile with JDK JNI headers and warnings enabled: PASS
- Native registry count: 28: PASS
- Required Android project files: PASS
- AndroidManifest launcher/exported activity: PASS
- CMake 3.22.1 configuration present: PASS
- AGP 9.3.0 configured: PASS
- Gradle CI 9.5.0 configured: PASS
- JDK 17 configured: PASS
- compileSdk 37 configured: PASS
- Build Tools 36.0.0 configured in CI: PASS
- NDK 28.2.13676358 configured: PASS
- JavaScript files in Android app: 0
- HTML files in Android app: 0
- CSS files in Android app: 0
- WebView/DOM dependency in Android source: 0
- Android workflow present: PASS
- Failing `android-actions/setup-android` dependency removed: PASS
- Direct runner SDK manager discovery added: PASS
- Project layout validation added: PASS
- Debug APK output validation added: PASS
- Unsigned release APK output validation added: PASS
- Artifact upload with missing-file failure enabled: PASS
- Signing secrets in repository: 0

## GitHub build scope

The GitHub Actions workflow is designed to perform the actual Android SDK/NDK/CMake installation and Gradle build on `ubuntu-24.04`. This environment does not contain the Android SDK/NDK, so a physical GitHub APK build is not falsely claimed as locally executed.

Expected artifacts after a successful GitHub Actions run:
- `SA-Calculator-debug-apk`
- `SA-Calculator-release-unsigned-apk`

The release APK is intentionally unsigned. Keep private signing keys outside the repository.
