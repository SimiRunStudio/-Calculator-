package com.sacalculator.android;

import android.app.*;
import android.os.Bundle;
import android.content.*;
import android.graphics.Color;
import android.graphics.Typeface;
import android.net.Uri;
import android.text.InputType;
import android.view.*;
import android.view.inputmethod.InputMethodManager;
import android.widget.*;
import java.text.SimpleDateFormat;
import java.util.*;

public class MainActivity extends Activity {
    static final int BLUE=Color.rgb(49,94,246), BG=Color.rgb(246,248,252), CARD=Color.WHITE, TEXT=Color.rgb(24,31,45), MUTED=Color.rgb(105,115,135), BORDER=Color.rgb(225,230,239), RED=Color.rgb(205,55,70);
    LinearLayout root, content; TextView title, subtitle; EditText search; String page="Home", selected="scientific"; boolean compact=false, highContrast=false; SharedPreferences prefs; Map<String,EditText> fields=new LinkedHashMap<>(); TextView result; final ArrayList<String> history=new ArrayList<>(); final HashSet<String> favorites=new HashSet<>();

    static class Field { String key,label,def; int type; String[] choices; Field(String k,String l,String d){key=k;label=l;def=d;type=0;} Field(String k,String l,String d,String...c){key=k;label=l;def=d;choices=c;type=1;} }
    static Field f(String k,String l,String d){return new Field(k,l,d);} static Field s(String k,String l,String d,String...c){return new Field(k,l,d,c);}
    static final Map<String,Field[]> SPECS=new HashMap<>();
    static { 
        SPECS.put("scientific",new Field[]{f("x","X","30"),s("op","Operation","sin","sin","cos","tan","asin","acos","atan","sinh","cosh","tanh","log","ln","sqrt","abs","pow"),s("angle","Angle","deg","deg","rad","grad"),f("y","Y / exponent","2")});
        SPECS.put("fraction",new Field[]{f("a","Numerator A","1"),f("b","Denominator B","2"),f("c","Numerator C","1"),f("d","Denominator D","3"),s("op","Operation","add","add","sub","mul","div")});
        SPECS.put("matrix",new Field[]{f("A","Matrix A","1 2\\n3 4"),f("B","Matrix B","5 6\\n7 8"),s("op","Operation","add","add","sub","mul","det","trans","inv","rank","trace","rref","eigen","lu")});
        SPECS.put("complex",new Field[]{f("ar","Real A","3"),f("ai","Imaginary A","2"),f("br","Real B","1"),f("bi","Imaginary B","4"),s("op","Operation","add","sub","mul","div","abs","arg","conj","polar","pow","root"),f("n","Power / root n","2")});
        SPECS.put("statistics",new Field[]{f("data","Data","1, 2, 3, 4, 5"),s("mode","Mode","summary","summary","zscore","percentile")});
        SPECS.put("probability",new Field[]{f("n","n","10"),f("r","r","3"),f("p","p","0.5"),f("x","x","5"),s("op","Operation","ncr","ncr","npr","binomial","binomialcdf","normalpdf","normalcdf")});
        SPECS.put("equation",new Field[]{f("a","a","1"),f("b","b","-3"),f("c","c","2"),s("op","Operation","quadratic","linear","system2x2")});
        SPECS.put("graphing",new Field[]{f("expression","f(x)","sin(x)"),f("xmin","X minimum","-10"),f("xmax","X maximum","10")});
        SPECS.put("percentage",new Field[]{f("a","A","250"),f("b","B","20"),s("op","Operation","of","change","whatpercent","increase","decrease")});
        SPECS.put("geometry",new Field[]{f("a","A / length","5"),f("b","B / width","3"),f("c","C / height","2"),s("op","Operation","rectangle","triangle","circle","cylinder","sphere","cone")});
        SPECS.put("unit",new Field[]{f("value","Value","1"),s("category","Category","Length","Length","Mass","Speed","Area","Volume","Time"),f("from","From unit","m"),f("to","To unit","km")});
        SPECS.put("loan",new Field[]{f("principal","Principal","100000"),f("rate","Annual rate %","8.5"),f("years","Years","5"),s("frequency","Payments/year","12","12","4","2","1")});
        SPECS.put("investment",new Field[]{f("initial","Initial","10000"),f("rate","Annual rate %","10"),f("years","Years","10"),f("contribution","Periodic contribution","1000"),s("frequency","Periods/year","12","12","4","2","1")});
        SPECS.put("shopping",new Field[]{f("subtotal","Subtotal","1000"),f("discount","Discount %","10"),f("tax","Tax %","18"),f("shipping","Shipping","50")});
        SPECS.put("datetime",new Field[]{f("a","Date A","2026-01-01"),f("b","Date B","2026-10-02"),f("days","Days","30"),s("op","Operation","diff","weekday","add","subtract")});
        SPECS.put("age",new Field[]{f("dob","Date of birth","2000-01-01"),f("asof","As of","2026-10-02")});
        SPECS.put("bmi",new Field[]{f("weight","Weight kg","70"),f("height","Height cm","175"),f("age","Age","25"),s("sex","Sex","male","male","female")});
        SPECS.put("fuel",new Field[]{f("price","Fuel price / L","100"),f("mileage","Mileage km/L","15"),f("tank","Tank L","40"),f("distance","Distance km","300")});
        SPECS.put("ev",new Field[]{f("battery","Battery kWh","60"),f("start","Start %","20"),f("target","Target %","80"),f("power","Charger kW","7"),f("price","Electricity / kWh","8"),f("loss","Charging loss %","10"),f("eff","Efficiency kWh/100km","15"),f("degrade","Degradation %/year","2"),f("years","Years","5"),s("op","Operation","charge","range","degraded")});
        SPECS.put("construction",new Field[]{f("a","Length / area","10"),f("b","Width","5"),f("c","Height","3"),f("waste","Waste %","5"),f("material","Material rate","100"),f("labor","Labor rate","50"),s("op","Operation","concrete","floor","paint","cost")});
        SPECS.put("electrical",new Field[]{f("v","Voltage V","230"),f("i","Current A","5"),f("r","Resistance Ω","46"),f("h","Hours","2"),f("pf","Power factor","0.9"),f("tariff","Tariff / kWh","8"),s("op","Operation","ohm","current","power","apparent","reactive","tariff","energy")});
        SPECS.put("programmer",new Field[]{f("value","Value","255"),f("other","Other","15"),f("shift","Shift","4"),s("op","Operation","bases","and","or","xor","left","right","not")});
        SPECS.put("datasize",new Field[]{f("value","Value","1024"),s("system","System","binary","binary","decimal"),f("from","From unit","KB"),f("to","To unit","MB")});
        SPECS.put("speedtime",new Field[]{f("distance","Distance km","120"),f("speed","Speed km/h","60"),f("time","Time h","2"),s("solve","Solve for","time","time","speed","distance")});
        SPECS.put("temperature",new Field[]{f("value","Value","25"),s("from","From","C","C","F","K","R"),s("to","To","F","C","F","K","R")});
        SPECS.put("regression",new Field[]{f("x","X data","1,2,3,4,5"),f("y","Y data","2,4,5,8,10")});
        SPECS.put("formula",new Field[]{f("expression","Expression","(12+8)*3/2")});
        SPECS.put("prime",new Field[]{f("n","Integer N","2305843009213693951"),f("m","Integer M","12"),s("op","Operation","check","check","gcd","lcm","totient","factor")});
    }

    @Override public void onCreate(Bundle b){super.onCreate(b); prefs=getSharedPreferences("sa_calculator",0); compact=prefs.getBoolean("compact",false); highContrast=prefs.getBoolean("contrast",false); loadLists(); buildShell(); showHome();}
    void loadLists(){String h=prefs.getString("history","");if(!h.isEmpty())history.addAll(Arrays.asList(h.split("\\n",-1)));String fv=prefs.getString("favorites","");if(!fv.isEmpty())favorites.addAll(Arrays.asList(fv.split(",")));}
    void saveLists(){prefs.edit().putString("history",String.join("\n",history)).putString("favorites",String.join(",",favorites)).putBoolean("compact",compact).putBoolean("contrast",highContrast).apply();}
    TextView tv(String t,float size,boolean bold){TextView v=new TextView(this);v.setText(t);v.setTextSize(size);v.setTextColor(highContrast?Color.BLACK:TEXT);v.setTypeface(bold?Typeface.DEFAULT_BOLD:Typeface.DEFAULT);v.setGravity(Gravity.CENTER_VERTICAL);v.setPadding(0,0,0,0);return v;}
    GradientDrawableLike bg(int c,int r){return new GradientDrawableLike(c,r);}
    void buildShell(){
        root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);root.setBackgroundColor(highContrast?Color.WHITE:BG);setContentView(root);
        LinearLayout top=new LinearLayout(this);top.setGravity(Gravity.CENTER_VERTICAL);top.setPadding(dp(20),dp(16),dp(20),dp(10));
        title=tv("SA Calculator",24,true);top.addView(title,new LinearLayout.LayoutParams(0,dp(42),1));
        Button more=button("⋮",false);more.setOnClickListener(v->showSettings());top.addView(more,new LinearLayout.LayoutParams(dp(48),dp(42)));root.addView(top);
        subtitle=tv("Native C++ engine • Android",12,false);subtitle.setTextColor(MUTED);subtitle.setPadding(dp(20),0,dp(20),dp(8));root.addView(subtitle,new LinearLayout.LayoutParams(-1,dp(28)));
        content=new LinearLayout(this);content.setOrientation(LinearLayout.VERTICAL);ScrollView sv=new ScrollView(this);sv.setFillViewport(true);sv.addView(content);root.addView(sv,new LinearLayout.LayoutParams(-1,0,1));
        LinearLayout nav=new LinearLayout(this);nav.setPadding(dp(8),dp(7),dp(8),dp(7));nav.setGravity(Gravity.CENTER);String[] ns={"Home","Tools","History","Favorites","Settings"};for(String n:ns){Button x=button(n,false);x.setOnClickListener(v->{page=n;refresh();});nav.addView(x,new LinearLayout.LayoutParams(0,dp(50),1));}root.addView(nav);
    }
    void refresh(){if(page.equals("Home"))showHome();else if(page.equals("Tools"))showTools();else if(page.equals("History"))showHistory();else if(page.equals("Favorites"))showFavorites();else showSettings();}
    void clear(){content.removeAllViews();}
    Button button(String text,boolean primary){Button b=new Button(this);b.setText(text);b.setTextSize(primary?14:12);b.setAllCaps(false);b.setTextColor(primary?Color.WHITE:(highContrast?Color.BLACK:TEXT));b.setMinHeight(dp(42));b.setPadding(dp(12),0,dp(12),0);b.setBackground(bg(primary?BLUE:CARD,12));return b;}
    void showHome(){clear(); title.setText("SA Calculator"); subtitle.setText("Fast native tools • clean workspace");
        LinearLayout hero=card();TextView h=tv("One calculator. 28 focused tools.",21,true);hero.addView(h);TextView p=tv("Native C++ calculation engine with persistent history and favorites.",13,false);p.setTextColor(MUTED);hero.addView(p);content.addView(hero,new LinearLayout.LayoutParams(-1,dp(compact?118:138)));
        search=new EditText(this);search.setHint("Search tools…");search.setSingleLine(true);search.setPadding(dp(14),0,dp(14),0);search.setBackground(bg(CARD,14));content.addView(search,margin(-1,dp(50),14,12,14,8));search.setOnEditorActionListener((v,a,e)->{showTools();return true;});
        LinearLayout grid=new LinearLayout(this);grid.setOrientation(LinearLayout.VERTICAL);String[][] rows={{"scientific","Scientific"},{"percentage","Percentage"},{"fraction","Fraction"},{"graphing","Graphing"},{"prime","Number Theory"},{"unit","Unit Converter"}};for(int i=0;i<rows.length;i+=2){LinearLayout row=new LinearLayout(this);for(int j=i;j<i+2&&j<rows.length;j++){Button c=button(rows[j][1],false);String id=rows[j][0];c.setOnClickListener(v->openTool(id));row.addView(c,margin(0,dp(58),6,6,6,6));}grid.addView(row,new LinearLayout.LayoutParams(-1,dp(70)));}content.addView(grid);
        TextView recent=tv("Recent",16,true);content.addView(recent,margin(-1,dp(34),14,8,14,4));if(history.isEmpty())empty("No calculations yet.");else for(int i=0;i<Math.min(4,history.size());i++)historyCard(history.get(i));
    }
    void showTools(){clear();title.setText("Tool Library");subtitle.setText("Search • open • calculate");EditText q=new EditText(this);q.setHint("Search 28 tools…");q.setSingleLine(true);q.setText(search==null?"":search.getText().toString());q.setBackground(bg(CARD,14));content.addView(q,margin(-1,dp(50),14,10,14,8));LinearLayout list=new LinearLayout(this);list.setOrientation(LinearLayout.VERTICAL);content.addView(list);q.addTextChangedListener(new android.text.TextWatcher(){public void beforeTextChanged(CharSequence s,int st,int c,int a){}public void onTextChanged(CharSequence s,int st,int b,int c){renderTools(list,s.toString());}public void afterTextChanged(android.text.Editable e){}});renderTools(list,q.getText().toString());}
    void renderTools(LinearLayout list,String q){list.removeAllViews();String[] r=NativeBridge.registry();for(String z:r){String[] a=z.split("\\|",-1);if(q.isEmpty()||z.toLowerCase().contains(q.toLowerCase())){LinearLayout row=card();Button open=button((favorites.contains(a[0])?"★ ":"☆ ")+a[1]+"  •  "+a[2],false);open.setGravity(Gravity.LEFT|Gravity.CENTER_VERTICAL);open.setOnClickListener(v->openTool(a[0]));row.addView(open,new LinearLayout.LayoutParams(-1,dp(compact?50:60)));list.addView(row);}}}
    void showHistory(){clear();title.setText("History");subtitle.setText("Last 100 successful calculations");if(history.isEmpty()){empty("No history yet.");return;}Button clearB=button("Clear history",false);clearB.setOnClickListener(v->{history.clear();saveLists();showHistory();});content.addView(clearB,margin(-1,dp(48),14,8,14,8));for(String h:history)historyCard(h);}
    void historyCard(String h){LinearLayout c=card();TextView t=tv(h.replace("\t","  "),14,false);c.addView(t,new LinearLayout.LayoutParams(0,dp(62),1));Button open=button("Open",false);open.setOnClickListener(v->{String[] p=h.split("\\t",4);if(p.length>0)openTool(p[0]);});c.addView(open,new LinearLayout.LayoutParams(dp(72),dp(50)));content.addView(c,margin(-1,dp(74),12,5,12,5));}
    void showFavorites(){clear();title.setText("Favorites");subtitle.setText("Your pinned tools");if(favorites.isEmpty()){empty("Tap ☆ in Tool Library to add favorites.");return;}for(String id:favorites){if(SPECS.containsKey(id)){Button b=button("★  "+titleFor(id),false);b.setGravity(Gravity.LEFT|Gravity.CENTER_VERTICAL);b.setOnClickListener(v->openTool(id));content.addView(b,margin(-1,dp(56),14,5,14,5));}}}
    void showSettings(){clear();title.setText("Settings");subtitle.setText("Simple, persistent preferences");Switch c=new Switch(this);c.setText("Compact layout");c.setChecked(compact);c.setTextSize(15);c.setPadding(dp(16),0,dp(16),0);c.setOnCheckedChangeListener((v,x)->{compact=x;saveLists();refresh();});content.addView(c,margin(-1,dp(60),14,8,14,8));Switch hc=new Switch(this);hc.setText("High contrast");hc.setChecked(highContrast);hc.setTextSize(15);hc.setPadding(dp(16),0,dp(16),0);hc.setOnCheckedChangeListener((v,x)->{highContrast=x;saveLists();recreate();});content.addView(hc,margin(-1,dp(60),14,8,14,8));TextView about=tv("Build 18.9.5\nC++17 engine • NDK • no JS/HTML/CSS\nAndroid-ready GitHub/Actions project",14,false);content.addView(about,margin(-1,dp(90),14,16,14,8));}
    void openTool(String id){selected=id;clear();title.setText(titleFor(id));subtitle.setText("Native engine • "+categoryFor(id));fields.clear();Field[] fs=SPECS.get(id);if(fs==null){empty("Tool form unavailable.");return;}LinearLayout form=card();for(Field f:fs){TextView lab=tv(f.label,12,true);lab.setTextColor(MUTED);form.addView(lab,margin(-1,dp(26),0,6,0,3));if(f.type==1){Spinner sp=new Spinner(this);ArrayAdapter<String>a=new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,f.choices);sp.setAdapter(a);int ix=Arrays.asList(f.choices).indexOf(f.def);if(ix>=0)sp.setSelection(ix);form.addView(sp,margin(-1,dp(50),0,0,0,8));EditText proxy=new EditText(this);proxy.setText(f.def);proxy.setVisibility(View.GONE);fields.put(f.key,proxy);sp.setTag(proxy);}else{EditText e=new EditText(this);e.setText(f.def);e.setTextSize(15);e.setSingleLine(!f.key.equals("A")&&!f.key.equals("B")&&!f.key.equals("data")&&!f.key.equals("x")&&!f.key.equals("y")&&!f.key.equals("expression"));e.setInputType(f.key.matches("date|expression|data|A|B|x|y")?InputType.TYPE_CLASS_TEXT:InputType.TYPE_CLASS_NUMBER|InputType.TYPE_NUMBER_FLAG_DECIMAL|InputType.TYPE_NUMBER_FLAG_SIGNED);e.setBackground(bg(CARD,12));form.addView(e,margin(-1,dp(50),0,0,0,8));fields.put(f.key,e);}}
        // Keep spinner values synchronized into hidden fields at run time.
        for(int i=0;i<form.getChildCount();i++){View v=form.getChildAt(i);if(v instanceof Spinner){Spinner sp=(Spinner)v;sp.setOnItemSelectedListener(new android.widget.AdapterView.OnItemSelectedListener(){public void onNothingSelected(android.widget.AdapterView<?>p){}public void onItemSelected(android.widget.AdapterView<?>p,View x,int pos,long id){((EditText)sp.getTag()).setText(String.valueOf(sp.getSelectedItem()));}});}}
        content.addView(form,margin(-1,-2,14,8,14,8));LinearLayout actions=new LinearLayout(this);Button run=button("RUN",true), reset=button("RESET",false), fav=button(favorites.contains(id)?"★ Favorite":"☆ Favorite",false);run.setOnClickListener(v->runTool());reset.setOnClickListener(v->openTool(id));fav.setOnClickListener(v->{if(favorites.contains(id))favorites.remove(id);else favorites.add(id);saveLists();fav.setText(favorites.contains(id)?"★ Favorite":"☆ Favorite");});actions.addView(run,margin(0,dp(52),4,4,4,4));actions.addView(reset,margin(0,dp(52),4,4,4,4));actions.addView(fav,margin(0,dp(52),4,4,4,4));content.addView(actions);result=tv("Result will appear here.",14,false);result.setGravity(Gravity.TOP|Gravity.LEFT);result.setPadding(dp(16),dp(16),dp(16),dp(16));result.setBackground(bg(CARD,14));content.addView(result,margin(-1,dp(190),14,8,14,20));}
    void runTool(){String[] k=new String[fields.size()],v=new String[fields.size()];int i=0;for(Map.Entry<String,EditText>e:fields.entrySet()){k[i]=e.getKey();v[i]=e.getValue().getText().toString().replace("\\n","\n");i++;}String out=NativeBridge.run(selected,k,v);result.setText(out.startsWith("OK\n")?out.substring(3):"Error\n"+out.substring(4));if(out.startsWith("OK\n")){String stamp=new SimpleDateFormat("yyyy-MM-dd HH:mm",Locale.US).format(new Date());String compactResult=(out.substring(3).replace("\n"," | ").length()>140?out.substring(3).replace("\n"," | ").substring(0,140):out.substring(3).replace("\n"," | "));history.removeIf(x->x.startsWith(selected+"\t"));history.add(0,selected+"\t"+stamp+"\t"+compactResult);while(history.size()>100)history.remove(history.size()-1);saveLists();}}
    String titleFor(String id){for(String z:NativeBridge.registry()){String[]a=z.split("\\|",-1);if(a[0].equals(id))return a[1];}return id;}
    String categoryFor(String id){for(String z:NativeBridge.registry()){String[]a=z.split("\\|",-1);if(a[0].equals(id))return a[2];}return "Tool";}
    void empty(String s){TextView x=tv(s,14,false);x.setTextColor(MUTED);x.setPadding(dp(20),dp(30),dp(20),dp(30));content.addView(x);}
    LinearLayout card(){LinearLayout l=new LinearLayout(this);l.setOrientation(LinearLayout.VERTICAL);l.setPadding(dp(16),dp(14),dp(16),dp(14));l.setBackground(bg(CARD,16));return l;}
    LinearLayout.LayoutParams margin(int w,int h,int l,int t,int r,int b){LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(w,h);p.setMargins(dp(l),dp(t),dp(r),dp(b));return p;}
    int dp(int x){return (int)(x*getResources().getDisplayMetrics().density+.5f);}
    static class GradientDrawableLike extends android.graphics.drawable.GradientDrawable{GradientDrawableLike(int c,int r){setColor(c);setCornerRadius(r*3);setStroke(1,Color.rgb(225,230,239));}}
    @Override public void onBackPressed(){if(!page.equals("Home")){page="Home";showHome();}else super.onBackPressed();}
}
